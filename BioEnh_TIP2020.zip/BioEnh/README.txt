INTRODUCTION
===================================================================================

This code is provided for research purposes only.
This code performs the method reported in:
Kai-Fu Yang, Xian-Shi Zhang, and Yong-Jie Li*. A Biological Vision Inspired Framework for Image Enhancement in Poor Visibility Conditions. IEEE Transactions on Image Processing, 2019, 29:1493-1506

Please cite our paper if this code is used to motivate any publications.
===================================================================================
USAGE��

run "DemoExample.m" for examples of image enhancement.

Let me know if you have any questions at
Kai-Fu Yang <yangkf@uestc.edu.cn>

===================================================================================
NOTES:
The results may be slightly different from that reported in TIP2021 because some bugs have been fixed in the codes.