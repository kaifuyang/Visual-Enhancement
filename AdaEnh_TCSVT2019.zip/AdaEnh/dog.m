function coeff = dog(sigma) 

wid = 21;
C1 = fspecial('gaussian',[wid wid],sigma);
S1 = fspecial('gaussian',[wid wid],3*sigma);

coeff = C1-S1; 