clc;  clear;

% 1. HDR scene example
imgpath = 'cathedral.hdr'; 
map = im2double(hdrread(imgpath)); 
figure;imshow(map);

Resimg = AdaEnhancement(map,'HDR'); % imgtype = {'HDR', 'night'}
figure;imshow(Resimg);
% figure;imhist(rgb2gray(Resimg));

% 2. night image example
imgpath = 'N-010-0.bmp';  % N-010-0.bmp
map = im2double(imread(imgpath)); 
figure;imshow(map);

Resimg = AdaEnhancement(map,'night'); % imgtype = {'HDR', 'night'}
figure;imshow(Resimg); 
