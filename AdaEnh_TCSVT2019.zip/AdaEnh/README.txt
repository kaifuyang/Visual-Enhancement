INTRODUCTION
===================================================================================

This code is provided for research purpose only.
This code performs Adaptive Dynamic Range Adjustment (ADRA) reported in:
  Kai-Fu Yang, Hui Li, Hulin Kuang, Chao-Yi Li, and Yong-Jie Li*. 
  An Adaptive Method for Image Dynamic Range Adjustment. IEEE Trans.CSVT,in press,2018.

Please cite our paper if this code is used to motivate any publications.

===================================================================================
USAGE��

 run "example.m" for examples of HDR scene tone mapping and night image enhancement.

Let us know if you have any questions at
Kai-Fu Yang <yangkf@uestc.edu.cn>

===================================================================================
NOTES:

1. There is a bug in original version 
2. Debug Version -- 2018.03.06  
   The results are slightly different with the results reported in TCSVT2018